Title: Speckit Backlog Demo
Feature: Speckit Backlog Provider
Description: Demo spec shipped with the Speckit add-in to exercise backlog ingestion.
Story: As an operator, I want Speckit tasks visible in the backlog so I can track work alongside Cognition.
Story Description: Provide a simple spec + tasks list that renders in the operator dashboard.
Status: backlog
Priority: medium
Size: small
