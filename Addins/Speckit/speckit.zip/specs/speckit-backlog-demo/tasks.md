# Speckit task list (demo)
[t] Wire add-in specs into the repo | priority=medium;size=small;tags=addon,backlog
[p] Confirm backlog provider loads Speckit specs | priority=high;size=medium;tags=ui,operator
[b] Capture follow-up improvements for Speckit ingest | priority=low;size=small;tags=notes
