#!/usr/bin/env bash
echo "Speckit Shell: hello from add-in!"
